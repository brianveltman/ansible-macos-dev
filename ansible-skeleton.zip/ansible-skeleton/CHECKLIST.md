# Ansible role development checklist

- [ ] Each role must be idempotent
- [ ] Each role must be able to be installed from scratch (false by default)
- [ ] Each role will completely remove it's dependencies and reinstall when versions do not match
- [ ] All variables need to have defaults
- [ ] Users should not be used a cross multiple roles (if you do so, you end up in dependency hell)

#### Coding style
- [ ] One statement or argument per line
- [ ] All task names start with the name of the role
