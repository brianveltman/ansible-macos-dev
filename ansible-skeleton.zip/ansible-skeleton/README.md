# TFS Linux Build Server
Ansible deployment scripts for deploying a TFS Linux Build Server

# Usage
## Development (if you used `--vagrant` flag: `vagrant up`
When you make changes, run `vagrant provision` to update your vms.

## Development

Create your own inventory copy for development purposes.

```
$ mv inventories/development.dist inventories/development
```

Set Ansible Vault password in a password file
```
$ export ANSIBLE_VAULT_PASSWORD_FILE=/tmp/tfs_vault_pass
```

Deploy to dev
```
$ make dev
```

## Production
```
$ make prod
```

## New target systems need a deployment npa
```
$ useradd tfs
$ usermod -aG tfs tfs
$ usermod -aG wheel tfs
$ passwd tfs
```
