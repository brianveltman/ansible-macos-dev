# Docker role

todos:
 - [ ] Change the docker deamon to listen on http(s) instead of socket
 - [ ] Secure docker deamon
 - [ ] Add support for private registry