#!/bin/bash

if [ -f /vagrant/inventories/local ];
    then
        echo 'inventory already active' 
    elif [ ! -f /vagrant/inventories/local.dist && ! -f /vagrant/inventories/local ];
        then
            echo 'No inventory to parse!'
    else
        sudo cp /vagrant/inventories/local.dist /vagrant/inventories/local
fi