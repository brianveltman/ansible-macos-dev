# Local Playbook Development

This repository includes setup files for local playbook development within a VirtualBox environment.
The purpose is to have a number of local linux buildservers which can be removed and installed over and over again to test idempotency. This way we can test the playbook behavior on new provisioned servers without going through the hassle of requesting new servers at IPC.

### Prerequisites
Please make sure you have the following applications installed:
- [ ] VirtualBox version: 5.2.16 or above
- [ ] Vagrant version: 2.1.2
**Note:** It's very important to have VirtualBox 5.2.16 or higher since this solves compatibility issues with the Linux kernel 3.10.0 which will be installed during provisioning of the virtual machines.

## Quick setup
- [ ] make sure you have the prerequisites as stated above
- [ ] Open up your terminal/command prompt and navigate to the root of this repo.
- [ ] Run `$ vagrant up` and get a coffee. On average a new setup takes about 15min.
- [ ] Done.



#### Required files (beside the Ansible files)
- [ ] certs.sh
- [ ] inventory.sh
- [ ] rootg3_b64.cer
- [ ] Vagrantfile


## What's really happening

When running `$ vagrant up` for the first time the contents of the Vagrantfile will be executed. The Vagrantfile is extensively covered with comments to explain what's happening.

## FAQ
How to run Ansible on already provisioned machines?
Simply just run the ansible provisoner `$ vagrant provision node3`

Can I run ansible directly from the controller node?
Yes you can by logging into the node, `$ vagrant ssh node3`

Is it possible to run the playbook against any of the provisioned nodes?
Yes. It's just a couple of VM's running Ansible.