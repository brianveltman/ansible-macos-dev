#!/bin/bash

echo "Installing ING CA certificates"
sudo cp /vagrant/rootg3_b64.cer /etc/pki/ca-trust/source/anchors/rootg3_b64.cer && sudo chmod 777 /etc/pki/ca-trust/source/anchors/rootg3_b64.cer
sudo openssl x509 -inform pem -in /etc/pki/ca-trust/source/anchors/rootg3_b64.cer -out /etc/pki/ca-trust/source/anchors/rootg3_b64.pem
sudo update-ca-trust && update-ca-trust enable
echo "Finished installing certificates"

echo "Installing yum packages and epel-repo"
sudo yum install curl wget gcc epel-release -y
echo "Finished installing packages and epel"

# ING processes the epel repository very slow.
# Therefore we have to allow yum to deal with slow transfers and have a higher timeout
# to prevent yum from cancelling the operation.
echo "Change epel.repo settings"
sudo yum-config-manager --save --setopt=epel.minrate=1
sudo yum-config-manager --save --setopt=epel.timeout=1200
echo "Finished epel.repo settings"
echo "Update yum"
sudo yum update -y