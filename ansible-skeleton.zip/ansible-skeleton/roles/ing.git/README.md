# Git role

#### Todo:
- [] remove the agent capability from this role once this role is made available through Galaxy
