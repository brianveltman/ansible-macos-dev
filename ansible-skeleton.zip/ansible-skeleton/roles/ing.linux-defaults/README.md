# Linux defaults role

This role ensures the most common packages and settings are present on the target machines.

**Note:** This role only ensures the default locale has been set to en_US.UTF-8. It does not install additional or missing language packs.
