#!/bin/bash

if [ -f /vagrant/inventories/local ];
    then
        echo 'inventory already active'
    elif [ ! -f /vagrant/inventories/local.dist && ! -f /vagrant/inventories/local ];
        then
            echo 'No inventory to parse!'
    else
        sudo cp /vagrant/inventories/local.dist /vagrant/inventories/local
fi

yum install python-pip python-virtualenv sshpass -y

pip install ansible==2.5.4 --index-url https://artifactory.ing.net/artifactory/api/pypi/pypi_python_org/simple --trusted-host artifactory.ing.net
